function OpenClothing(stationName)
    if Config.Clothing == "illenium-appearance" or Config.Clothing == "fivem-appearance" then
        local Player = FW_GetPlayerData(false)
        local retval = {}
        for _, v in pairs(Config.Outfits[GetGender()]) do
            if v.grades == nil then
                table.insert(retval, v)
            else
                local canBeAdded1 = false
                local canBeAdded2 = false
                local canBeAdded3 = false
                for _, u in pairs(v.grades) do
                    if u == Player.job.grade.level then
                        canBeAdded1 = true
                    end
                end
                for _, u in pairs(v.job) do
                    if u == Player.job.name then
                        canBeAdded2 = true
                    end
                end
                for _, u in pairs(v.maps) do
                    if u == stationName then
                        canBeAdded3 = true
                    end
                end
                if canBeAdded1 and canBeAdded2 and canBeAdded3 then
                    table.insert(retval, v)
                end
            end
        end
        if #retval == 0 then
            Debuger("No outfits available for job: "..Player.job.name..", grade: "..Player.job.grade.level.." and map: "..stationName..".")
            Debuger("To fix this, add an outfit to the config file with the correct job, grade and map.")
            return
        end
        TriggerEvent(Config.Clothing..":client:openJobOutfitsMenu", retval)
    elseif Config.Clothing == "qb-clothing" then
        local Player = FW_GetPlayerData(false)
        exports["qb-clothing"]:getOutfits(Player.job.grade.level, Config.Outfits)
    elseif Config.Clothing == "codem-appearance" then
        exports['codem-appearance']:OpenMenu("job")
    elseif Config.Clothing == "tgiann-clothing" then
        exports["tgiann-clothing"]:OpenJobOutiftMenu("police1")
    elseif Config.Clothing == "dx_clothing" then
        exports['dx_clothing']:openJobsOutfitMenu(false)
    elseif Config.Clothing == "rcore_clothing" then
        TriggerEvent('rcore_clothing:openJobChangingRoom', Config.PoliceJobName, {
            label = 'Police Clothing',
            pos = GetEntityCoords(PlayerPedId())
        })
    elseif Config.Clothing == "origen_clothing" then
        exports["origen_clothing"]:openOutfitMenu(true)
    else
        print("No supported clothing found.")
    end
end

function SetCriminalClothes(gender, PlayerData)
    if gender then
        local ped = PlayerPedId()
        if type(PlayerData.metadata.criminalclothe) == "table" then
            if Config.Clothing == "qb-clothing" then
                TriggerEvent("qb-clothing:client:loadOutfit", {
                    outfitData = PlayerData.metadata.criminalclothe
                })
            elseif Config.Clothing == "illenium-appearance" then
                exports["illenium-appearance"]:setPedAppearance(ped, PlayerData.metadata.criminalclothe)
            elseif Config.Clothing == "fivem-appearance" then
                exports["fivem-appearance"]:setPedAppearance(ped, PlayerData.metadata.criminalclothe)
            elseif Config.Clothing == "origen_clothing" then
                exports["origen_clothing"]:SetAppearance(ped, PlayerData.metadata.criminalclothe)
            end
            TriggerServerEvent("origen_police:SetMetaData", "criminalclothe", 0)
            ShowNotification(Config.Translations.ChangedCloth)
        else
            if Public.CriminalClothe and Public.CriminalClothe[gender] then
                if Config.Clothing == "qb-clothing" then
                    local skin = {}
                    local success, _ = pcall(function()
                        skin = exports["qb-clothing"]:GetSkinData()
                    end)
                    if not success then
                        return Debuger("[^1ERROR^0] The export (GetSkinData) does not exist in your qb-clothing resource.")
                    end
                    TriggerServerEvent("origen_police:SetMetaData", "criminalclothe", skin)
                    TriggerEvent("qb-clothing:client:loadOutfit", {
                        outfitData = Public.CriminalClothe[gender]
                    })
                elseif Config.Clothing == "illenium-appearance" then
                    TriggerServerEvent("origen_police:SetMetaData", "criminalclothe", exports["illenium-appearance"]:getPedAppearance(ped))
                    exports["illenium-appearance"]:setPedAppearance(ped, Public.CriminalClothe[gender])
                elseif Config.Clothing == "fivem-appearance" then
                    TriggerServerEvent("origen_police:SetMetaData", "criminalclothe", exports["fivem-appearance"]:getPedAppearance(ped))
                    exports["fivem-appearance"]:setPedAppearance(ped, Public.CriminalClothe[gender])
                elseif Config.Clothing == "origen_clothing" then
                    TriggerServerEvent("origen_police:SetMetaData", "criminalclothe", exports["origen_clothing"]:GetAppearanceData(ped))
                    exports["origen_clothing"]:SetAppearance(ped, Public.CriminalClothe[gender])
                end

                ShowNotification(Config.Translations.ChangedCloth)
            else
                ShowNotification(Config.Translations.NoFederalClothAvailable)
            end
        end
    else
        ShowNotification(Config.Translations.PedCantChangeCloth)
    end
end